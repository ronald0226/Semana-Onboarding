Puntos De contol
Fase 1: la ruta absoluta,es la direccion completa de un archivo o carpeta home/Riwi./temporal/conservar.txt
mientras que la ruta relativa, es la direccion de un archivo o carpeta /temporal/conservar.txt

Fase 2:porque los nombres que comienzan con un punto se consideran ocultos en linux, se pueden escribir entre comillas

Fase 3:> se usa para escribir una informacion remplazando el contenido anterior si exite >> mientras este se utiliza para agregar informacion al final del archivo sin borrar lo que ya tiene

Fase 5: permite mover y renombrar porque cambia la ubicacion o el nombre de los archivos

Fase 6: con el cp se copia los archivos mientras que con el cp -r se copia la carpeta y todo el contenido 

Fase 7: buscar por archivo encuentra archivos segun su nombre,mientras que la busqueda por contenido encuentra archivos que contienen palabra o frase especifica 

Fase 8:porque cuando tiene contenido toca entrar a la carpeta y eliminar los archivos y ahora si ya eliminar la carpeta
