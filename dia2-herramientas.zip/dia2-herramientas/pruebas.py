print("Hola Verdolaga")
#numero1 =input("Dame el numero 1:")
#numero2 =input("Dame el numero 2:")
#resultado= print(numero1+numero2)

print("Bienvenido")
nombre=input("ingresa tu nombre:")
edad=int(input("ingresa tu edad:"))
if edad>=18:
    print(nombre + "no es mayor de edad")
else:
    print(nombre + "es mayor de edad")

    if suma>=10:
        