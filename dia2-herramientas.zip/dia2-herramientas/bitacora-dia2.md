# Bitácora · Día 2 · Herramientas de desarrollo

- **Coder:**Ronald Mosquera
- **Fecha:**15/10/26
- **TL:**Johan rivera

---

## 1. Mi entorno de desarrollo (Etapa 1)

- Versión de Ubuntu:  se puede consultar con lsb_release -d
- Versión de Python:se consulta con python3 --version
- ¿Dónde está instalado Python? (resultado de `which python3`):
- Con mis palabras, la diferencia entre un compilador y un intérprete es:un compilador traduce el codigo a otro formato antes de ejecutarlo y un iterprete ejecuta las acciones en un programa que las procesa
- ¿Qué pasó con la línea 4 de `hola.py` y por qué?:python detuvo la ejecucion y mostro un mensaje de error dodnde estaba el problema.

| Herramienta | ¿Qué es? (sistema operativo, editor, intérprete, compilador o navegador) |
|---|---|
| Ubuntu |sistema operativo basado en linux |
| VS Code |editor de cogido fuente |
| Python |lenguaje de programacion |
| Chrome |navegador web |
| gcc |compilador para lenguajes |

## 2. Reinstalación de VS Code (Etapa 2)

- ¿Cómo estaba instalado VS Code? (snap, .deb o no estaba):snap
- Comando que usé para desinstalarlo: sudo snap remove code
- Comando que usé para instalarlo: sudo apt install ./code_*.deb
- ¿Por qué es importante instalar desde la fuente oficial?: para tener una version legitima y evitar virus de fuentes no confiables
- ¿Qué pasó con mi configuración al desinstalar? ¿Dónde vive?:la configuracion permanece despues de desintalar

## 3. Perfiles y extensiones (Etapa 3)

- Con mis palabras, un perfil de VS Code es: es una configuracion personalizada del editor
- ¿Qué cambia en el Explorador entre un perfil y otro?:la manera en que se muestran los archivos
- ¿Por qué VS Code pregunta si confío en el publicador de una extensión?:porque una extension puede acceder a archivos u ejecutar codigo

## 4. Duelo de perfiles (Etapa 4)

| Prueba | Perfil2-Basico | Perfil1-Pro |
|---|---|---|
| 1. Auto guardado |en este perfil esta desactivado |en este perfil esta con la configuracion para guardar automaticamente |      
| 2. Auto Rename Tag |no tiene la extension |tiene la extension instalada |
| 3. Error Lens |no tiene la extension |tiene la extension instalada |
| 4. Íconos |predeterminados de VS |iconos personalizados por una extension |
| 5. Guías de indentación |guias predeterminadas |guias configuradas por una extension |
| 6. Extensiones corriendo |ninguna extension instalada |extensiones instaladas y activas |

**Reflexión**

1. ¿Noté diferencias en la experiencia de trabajo entre los dos perfiles? ¿Cuáles?
   -el perfilpro puede facilitar el trabajo por las extensiones y configuraciones que le detectan a uno los errores
2. ¿Qué ventajas tiene usar múltiples perfiles en VS Code?
   -permite separar las herramientas y configuraciones para distintos proyectos
3. ¿Cómo influyen las extensiones en la productividad y en el rendimiento del editor?   -aumentan la productividad porque al automatiza tareas y detecta errores
4. ¿Cuándo sería útil usar perfiles distintos en un entorno profesional? (dos ejemplos)
   -para desarrollo web y programacion en python

## 5. Inspección y modificación (Etapa 5)

- Página que usé: https://es.wikipedia.org/wiki/Wiki
- Cinco etiquetas que encontré y para qué sirven:
  1.h1-h6 para titulos
  2.html se usa para crear la estructura de la pagina
  3.head contiene informacion sobre la pagina
  4.body contiene lo que las personas ven en la pagina
  5.script permite agregar acciones e interactividad
- ¿Qué pasó con mis cambios al recargar y por qué?: al darle al f5 y salime del panel se cambio todo y quedo la pagina original como estaba
- Con mis palabras, el DOM es:copia de la pagina que vive en la memoria

## 6. La consola (Etapa 6)

| Operación | Mi predicción | Resultado real |
|---|---|---|
| `2 + 3` | 5|5 |
| `10 - 4 * 2` |2 |2 |
| `(10 - 4) * 2` |12 |12 |
| `10 / 4` | 2.5|2.5 |
| `10 % 3` |1 |1 |
| `2 ** 8` |256 |256 |
| `120000 * 0.19` |22800 |22800 |
| `365 * 24` |8760 |8760 |

- ¿Por qué `0.1 + 0.2` no da exactamente `0.3`?: los computadores guardan los numeros decimales en binario y no se puede representar exactamente
- Errores o advertencias que encontré en la página (o "ninguno"):ninguno
- Diferencia entre un error y una advertencia:advertencia es algo que podria causar un problema mientras que el error indica un problema que puede impedir que algo funcione correctamente

## 7. La red / Network (Etapa 7)

| Imagen | Formato | Tamaño | Tiempo | Código de estado |
|---|---|---|---|---|
|imagen1 |.png |400x173 |241 ms |200 |
|arrow |-left |24x24 |240 ms |200 |
|arrow |-right |24x24 |240 ms |200 |

| Experimento | Solicitudes | Transferido | Load |
|---|---|---|---|
| A. Sin caché |179 |50.35MB |53 ms |
| B. Con caché |190 |52.62MB |8 ms |
| C. Red lenta |170 |45.93MB |1.73min |

- Archivo más pesado de la página y su tipo: wiew.genially json
- ¿Por qué la página cargó más rápido con caché?: porque la carche guarda datos para que no se vuelvan a repetir
- ¿Por qué un desarrollador querría probar con una red lenta?: para conocer como le fluye a las personas que tienen ese tipo red
- ¿Qué haría para que una imagen pesada cargue más rápido?: disable cache

## 8. Dispositivos móviles (Etapa 8)

| Ancho (px) | Dispositivo | ¿Cambia el menú? | ¿Imágenes bien? | ¿Scroll horizontal? | Observación |
|---|---|---|---|---|---|
| 320 |Responsive |si |si |no |ninguna |
| 375 |Responsive |si |si |no |ninguna |
| 768 |Responsive |si |si |no |ninguna |
| 1024 |Responsive |si |si |no |ninguna |
| 1440 |Responsive |si |no |no |ninguna |

- ¿Por qué es importante probar varias resoluciones antes de entregar un proyecto?: para saber cual es la resolucion acorde para entregar tal proyecto

## 9. Laboratorio de errores (Etapa 9)

| # | Tipo | ¿Dónde lo detecté? | Mensaje o síntoma | Causa | Solución aplicada |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |

- Uno de los errores, descrito con detalle, y cómo lo resolví:
- ¿Qué vi al pausar con el breakpoint?:
- ¿Qué pasó al cambiar `visitas` por 99 y al borrarlo?:
- ¿Para qué usan el localStorage las páginas reales? ¿Qué NO debería guardar ahí?:
- Ancho exacto en el que se apilan las tarjetas y regla de CSS responsable:
- ¿Por qué no basta con mirar solo la consola para encontrar errores?:

## 10. Comparación con Firefox (Etapa 10)

| Herramienta | Chrome: nombre y atajo | Firefox: nombre y atajo | Diferencia que noté |
|---|---|---|---|
| Inspeccionar HTML y CSS | | | |
| Consola | | | |
| Red | | | |
| Simulación de dispositivos | | | |
| Almacenamiento local | | | |
| Mensaje del error que reintroduje | | | |

- Una característica de Firefox interesante o diferente a Chrome (qué es, para qué sirve y cómo la probé):

## 11. Reflexión final (Etapa 11)

- La herramienta que más voy a usar y por qué:
- Lo más difícil del día y cómo lo resolví:
- Las DevTools explicadas para alguien que no programa (3 líneas):
